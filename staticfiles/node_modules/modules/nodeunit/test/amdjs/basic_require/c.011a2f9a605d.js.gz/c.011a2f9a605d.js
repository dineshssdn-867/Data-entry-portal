define('c', ['require'], function (require) {
    return {
        name: 'c',
        url: require.toUrl('./c/templates/first.txt')
    };
});
